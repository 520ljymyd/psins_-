function avperr = avperrset(phi, dvn, dpos)
% avp errors setting.
%  导航姿态attitude，速度velocity，位置position avp初始误差设置
% Prototype: avperr = avperrset(phi, dvn, dpos)  
% Inputs: phi - platform misalignment angles. all in arcmin  姿态误差
%         dvn - velocity errors in m/s  速度误差
%         dpos - position errors dpos=[dlat;dlon;dhgt], all in m  位置误差
% Output: avperr = [phi; dvn; dpos]
% 
% See also  poserrset, vperrset, avpadderr, imuerrset, avpset, insupdate, avperrstd.

% Copyright(c) 2009-2014, by Gongmin Yan, All rights reserved.
% Northwestern Polytechnical University, Xi An, P.R.China
% 08/03/2014
global glv
    avperr = [rep3(phi)*glv.min; vperrset(dvn,dpos)];



    %平台的初始姿态误差（横滚、俯仰、航向），单位为弧度
    %速度误差（东、北、垂直方向），单位为米/秒
    %位置误差（纬度、经度、高度），单位为米